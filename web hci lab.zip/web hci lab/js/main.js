const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');

hamburger.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

document.addEventListener("DOMContentLoaded", function () {
  const popup = document.getElementById("popup");
  const popupMessage = document.getElementById("popup-message");
  const buyNowLink = document.getElementById("buy-now-link");
  const closeBtn = document.getElementById("close-popup");

  window.openPopup = function (shipName) {
    popup.style.display = "flex";
    popupMessage.innerHTML = `Are you sure you want to buy <strong>${shipName}</strong>?`;
    buyNowLink.href = "https://docs.google.com/forms/d/e/1FAIpQLSejPAQW3CfSF6zLIAGk1zYzbn6C4zacTWZWQIiu1LXMajlr8w/viewform?usp=header";
  };

  closeBtn.addEventListener("click", function () {
    popup.style.display = "none";
  });
});

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("subscribeForm");
  const message = document.getElementById("formMessage");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const age = parseInt(document.getElementById("age").value.trim());
    const country = document.getElementById("country").value;

    message.textContent = "";
    message.style.color = "red";

    if (name === "") {
      message.textContent = "Name is required.";
      return;
    }

    if (!email.includes("@")) {
      message.textContent = "Email must contain '@'.";
      return;
    }

    if (password.length < 6) {
      message.textContent = "Password must be at least 6 characters.";
      return;
    }

    if (isNaN(age) || age < 17) {
      message.textContent = "You must be at least 17 years old.";
      return;
    }

    if (country === "") {
      message.textContent = "Please select your country.";
      return;
    }

    // All fields passed
    message.style.color = "green";
    message.textContent = "SUCCESSFULLY REGISTERED!";
    form.reset();
  });
});